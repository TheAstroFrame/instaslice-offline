/* Local celestial WCS projection and catalogue annotations. */
(() => {
  'use strict';

  const radians = Math.PI / 180;
  const wcsReadLimit = 1024 * 1024;
  const objectTypes = Object.freeze({
    '*': 'Star',
    '**': 'Double star',
    '*Ass': 'Stellar association',
    'Cl+N': 'Cluster with nebula',
    DrkN: 'Dark nebula',
    EmN: 'Emission nebula',
    G: 'Galaxy',
    GCl: 'Globular cluster',
    GGroup: 'Galaxy group',
    GPair: 'Galaxy pair',
    GTrpl: 'Galaxy triplet',
    HII: 'Emission nebula',
    Neb: 'Nebula',
    Nova: 'Nova',
    OCl: 'Open cluster',
    PN: 'Planetary nebula',
    RfN: 'Reflection nebula',
    SNR: 'Supernova remnant',
    Other: 'Other catalogue object'
  });

  function readHeader(input) {
    if (input instanceof ArrayBuffer) input = new Uint8Array(input);
    if (ArrayBuffer.isView(input)) {
      input = new TextDecoder().decode(
        new Uint8Array(input.buffer, input.byteOffset, Math.min(input.byteLength, wcsReadLimit))
      );
    }
    if (input && typeof input === 'object') {
      return Object.fromEntries(Object.entries(input).map(([key, value]) => [key.toUpperCase(), value]));
    }
    if (typeof input !== 'string') throw new Error('Choose a FITS WCS header for this image.');

    const header = Object.create(null);
    const text = input.replace(/^\uFEFF/, '').slice(0, wcsReadLimit).trimStart();
    const firstBreak = text.search(/[\r\n]/);
    const newlineSeparated = firstBreak >= 0 && firstBreak <= 80;
    const cards = newlineSeparated ? text.split(/\r?\n/) : text.match(/[\s\S]{1,80}/g) || [];
    for (const card of cards) {
      if (card.trim() === 'END') break;
      const match = card.match(/^\s*([A-Z0-9_-]{1,8})\s*=\s*(.*)/i);
      if (!match) continue;
      const [, key, rawValue] = match;
      const quoted = rawValue.match(/^'((?:[^']|'')*)'/);
      const value = quoted
        ? quoted[1].replace(/''/g, "'").trim()
        : rawValue.split('/')[0].trim();
      header[key.toUpperCase()] = value;
    }
    return header;
  }

  function number(header, key, fallback = NaN) {
    const value = header[key];
    if (typeof value === 'number') return value;
    if (typeof value !== 'string' || !value.trim()) return fallback;
    const parsed = Number(value.replace(/[dD]/, 'E'));
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function text(header, key) {
    const value = header[key];
    return typeof value === 'string' ? value.trim().toUpperCase() : '';
  }

  function dimension(header, imageKey, axisKey, fallback) {
    for (const value of [number(header, imageKey), number(header, axisKey), fallback]) {
      if (Number.isSafeInteger(value) && value > 0) return value;
    }
    throw new Error('The WCS does not specify image dimensions. Load the matching image first.');
  }

  function unitDegrees(header, key) {
    const unit = text(header, key);
    if (!unit || unit === 'DEG') return 1;
    if (unit === 'RAD') return 1 / radians;
    if (unit === 'ARCSEC') return 1 / 3600;
    if (unit === 'ARCMIN') return 1 / 60;
    throw new Error('The WCS uses unsupported sky-coordinate units.');
  }

  function readMatrix(header) {
    let values;
    const cdKeys = ['CD1_1', 'CD1_2', 'CD2_1', 'CD2_2'];
    const pcKeys = ['PC1_1', 'PC1_2', 'PC2_1', 'PC2_2'];
    if (cdKeys.some(key => key in header)) {
      values = cdKeys.map(key => number(header, key, 0));
    } else {
      const axis1 = number(header, 'CDELT1', 1);
      const axis2 = number(header, 'CDELT2', 1);
      if (pcKeys.some(key => key in header)) {
        values = [
          axis1 * number(header, 'PC1_1', 1),
          axis1 * number(header, 'PC1_2', 0),
          axis2 * number(header, 'PC2_1', 0),
          axis2 * number(header, 'PC2_2', 1)
        ];
      } else {
        const angle = number(header, 'CROTA2', number(header, 'CROTA1', 0)) * radians;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        values = [axis1 * cos, -axis2 * sin, axis1 * sin, axis2 * cos];
      }
    }
    const factor1 = unitDegrees(header, 'CUNIT1');
    const factor2 = unitDegrees(header, 'CUNIT2');
    return [values[0] * factor1, values[1] * factor1, values[2] * factor2, values[3] * factor2];
  }

  function readSip(header, prefix) {
    const order = number(header, prefix + '_ORDER', 0);
    if (!Number.isInteger(order) || order < 0 || order > 9) {
      throw new Error('The WCS uses an unsupported SIP polynomial order.');
    }
    const terms = [];
    for (let i = 0; i <= order; i++) {
      for (let j = 0; i + j <= order; j++) {
        const coefficient = number(header, prefix + '_' + i + '_' + j, 0);
        if (coefficient) terms.push({ i, j, coefficient });
      }
    }
    return terms;
  }

  function polynomial(terms, u, v) {
    let value = 0;
    for (const { i, j, coefficient } of terms) value += coefficient * u ** i * v ** j;
    return value;
  }

  function sipDerivatives(terms, u, v) {
    let du = 0;
    let dv = 0;
    for (const { i, j, coefficient } of terms) {
      if (i) du += coefficient * i * u ** (i - 1) * v ** j;
      if (j) dv += coefficient * j * u ** i * v ** (j - 1);
    }
    return [du, dv];
  }

  function inverseSip(targetU, targetV, a, b) {
    // Solve the forward SIP equations directly. The optional inverse SIP
    // polynomials are approximations and may be absent from a valid header.
    let u = targetU;
    let v = targetV;
    for (let attempt = 0; attempt < 15; attempt++) {
      const errorU = u + polynomial(a, u, v) - targetU;
      const errorV = v + polynomial(b, u, v) - targetV;
      if (Math.max(Math.abs(errorU), Math.abs(errorV)) < 1e-5) return [u, v];
      const [aU, aV] = sipDerivatives(a, u, v);
      const [bU, bV] = sipDerivatives(b, u, v);
      const determinant = (1 + aU) * (1 + bV) - aV * bU;
      if (!Number.isFinite(determinant) || Math.abs(determinant) < 1e-12) return null;
      u -= ((1 + bV) * errorU - aV * errorV) / determinant;
      v -= ((1 + aU) * errorV - bU * errorU) / determinant;
    }
    return null;
  }

  function separation(first, second) {
    const declination1 = first.dec * radians;
    const declination2 = second.dec * radians;
    const sinDec = Math.sin((declination2 - declination1) / 2);
    const sinRa = Math.sin((second.ra - first.ra) * radians / 2);
    const halfChord = sinDec ** 2 + Math.cos(declination1) * Math.cos(declination2) * sinRa ** 2;
    return 2 * Math.asin(Math.sqrt(Math.max(0, Math.min(1, halfChord)))) / radians;
  }

  function parseWcs(input, options = {}) {
    const header = readHeader(input);
    const axisOne = text(header, 'CTYPE1');
    const axisTwo = text(header, 'CTYPE2');
    const raFirst = /^RA---TAN(?:-SIP)?$/.test(axisOne) && /^DEC--TAN(?:-SIP)?$/.test(axisTwo);
    const decFirst = /^DEC--TAN(?:-SIP)?$/.test(axisOne) && /^RA---TAN(?:-SIP)?$/.test(axisTwo);
    if (!raFirst && !decFirst) throw new Error('This WCS is not an equatorial TAN or TAN-SIP solution.');

    const equinox = number(header, 'EQUINOX', number(header, 'EPOCH', 2000));
    const frame = text(header, 'RADESYS') || text(header, 'RADECSYS');
    if ((frame && frame !== 'ICRS' && frame !== 'FK5') || (frame !== 'ICRS' && equinox !== 2000)) {
      throw new Error('This WCS must use ICRS or J2000 equatorial coordinates.');
    }
    if (Object.keys(header).some(key => /^PV[12]_\d+$/.test(key))) {
      throw new Error('This WCS includes unsupported PV projection parameters.');
    }

    const width = dimension(header, 'IMAGEW', 'NAXIS1', options.width);
    const height = dimension(header, 'IMAGEH', 'NAXIS2', options.height);
    const rowOrigin = options.rowOrigin || 'bottom';
    if (rowOrigin !== 'top' && rowOrigin !== 'bottom') throw new Error('Invalid WCS row orientation.');

    const crpixX = number(header, 'CRPIX1');
    const crpixY = number(header, 'CRPIX2');
    const crval1 = number(header, 'CRVAL1') * unitDegrees(header, 'CUNIT1');
    const crval2 = number(header, 'CRVAL2') * unitDegrees(header, 'CUNIT2');
    const refRa = (raFirst ? crval1 : crval2) * radians;
    const refDec = (raFirst ? crval2 : crval1) * radians;
    const [m11, m12, m21, m22] = readMatrix(header);
    const [cd11, cd12, cd21, cd22] = raFirst ? [m11, m12, m21, m22] : [m21, m22, m11, m12];
    const determinant = cd11 * cd22 - cd12 * cd21;
    if (![crpixX, crpixY, refRa, refDec, determinant].every(Number.isFinite)
        || Math.abs(refDec) > Math.PI / 2 || determinant === 0) {
      throw new Error('The WCS does not contain a valid reference point and pixel transformation.');
    }
    const sinDec = Math.sin(refDec);
    const cosDec = Math.cos(refDec);
    const defaultPole = refDec === Math.PI / 2 ? 0 : 180;
    const poleAngle = (number(header, 'LONPOLE', defaultPole) - 180) * radians;
    const sinPole = Math.sin(poleAngle);
    const cosPole = Math.cos(poleAngle);
    const a = readSip(header, 'A');
    const b = readSip(header, 'B');

    // WCS pixels are 1-based. The raster row order is chosen separately from
    // the CD parity: Astrometry.net preserves JPEG/PNG row order in .wcs.
    function pixelToWorld(x, y) {
      if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
      const u = x + 1 - crpixX;
      const v = (rowOrigin === 'top' ? y + 1 : height - y) - crpixY;
      const correctedU = u + polynomial(a, u, v);
      const correctedV = v + polynomial(b, u, v);
      const plateX = (cd11 * correctedU + cd12 * correctedV) * radians;
      const plateY = (cd21 * correctedU + cd22 * correctedV) * radians;
      const east = cosPole * plateX + sinPole * plateY;
      const north = -sinPole * plateX + cosPole * plateY;
      const meridian = cosDec - north * sinDec;
      const ra = (refRa + Math.atan2(east, meridian)) / radians;
      const dec = Math.atan2(sinDec + north * cosDec, Math.hypot(east, meridian)) / radians;
      return { ra: ((ra % 360) + 360) % 360, dec };
    }

    function worldToPixel(ra, dec) {
      if (!Number.isFinite(ra) || !Number.isFinite(dec) || Math.abs(dec) > 90) return null;
      const deltaRa = ra * radians - refRa;
      const skyDec = dec * radians;
      const skySin = Math.sin(skyDec);
      const skyCos = Math.cos(skyDec);
      const cosDelta = Math.cos(deltaRa);
      const denominator = sinDec * skySin + cosDec * skyCos * cosDelta;
      if (denominator <= 1e-12) return null;
      const east = skyCos * Math.sin(deltaRa) / denominator / radians;
      const north = (cosDec * skySin - sinDec * skyCos * cosDelta) / denominator / radians;
      const plateX = cosPole * east - sinPole * north;
      const plateY = sinPole * east + cosPole * north;
      const targetU = (cd22 * plateX - cd12 * plateY) / determinant;
      const targetV = (cd11 * plateY - cd21 * plateX) / determinant;
      const uv = a.length || b.length ? inverseSip(targetU, targetV, a, b) : [targetU, targetV];
      if (!uv) return null;
      const x = uv[0] + crpixX - 1;
      const y = rowOrigin === 'top' ? uv[1] + crpixY - 1 : height - uv[1] - crpixY;
      return { x, y };
    }

    const cx = (width - 1) / 2;
    const cy = (height - 1) / 2;
    const center = pixelToWorld(cx, cy);
    const fov = {
      width_deg: separation(pixelToWorld(-0.5, cy), pixelToWorld(width - 0.5, cy)),
      height_deg: separation(pixelToWorld(cx, -0.5), pixelToWorld(cx, height - 0.5))
    };
    const scale_arcsec = Math.sqrt(Math.abs(determinant)) * 3600;
    return { solved: true, width, height, center, fov, scale_arcsec, worldToPixel, pixelToWorld };
  }

  const stellariumTypes = Object.freeze({
    G: 'Galaxy', GX: 'Galaxy', AGX: 'Active galaxy', RG: 'Radio galaxy',
    IG: 'Interacting galaxy', IG2: 'Galaxy pair', IG3: 'Galaxy triplet',
    GIG: 'Galaxy in a group', POG: 'Part of a galaxy', CGG: 'Galaxy group',
    CLG: 'Galaxy cluster', GXCL: 'Galaxy cluster', SCG: 'Galaxy supercluster',
    GC: 'Globular cluster', OC: 'Open cluster', OPC: 'Open cluster', CL: 'Cluster',
    NB: 'Nebula', DN: 'Dark nebula', DNE: 'Dark nebula', RN: 'Reflection nebula',
    RNE: 'Reflection nebula', EN: 'Emission nebula', HII: 'H II emission region',
    PN: 'Planetary nebula', PNB: 'Planetary nebula', 'PN?': 'Planetary nebula candidate',
    PPN: 'Protoplanetary nebula', BN: 'Bipolar nebula', 'C+N': 'Cluster with nebulosity',
    SNR: 'Supernova remnant', SNRG: 'Supernova remnant', 'SR?': 'Supernova remnant candidate',
    SNC: 'Supernova candidate', SNRC: 'Supernova remnant candidate',
    MOC: 'Molecular cloud', SFR: 'Star-forming region', ISM: 'Interstellar cloud',
    BUB: 'Interstellar bubble', EMO: 'Emission object', SA: 'Stellar association',
    SC: 'Star cloud', YSO: 'Young stellar object', 'Y*O': 'Young stellar object',
    '*': 'Star', '**': 'Double star', MUL: 'Multiple star', 'SY*': 'Symbiotic star',
    'EM*': 'Emission-line star', 'V*': 'Variable star', 'WD*': 'White dwarf',
    'TT*': 'T Tauri star', 'C*': 'Carbon star', 'NO*': 'Nova',
    QSO: 'Quasar', 'Q?': 'Quasar candidate', BLL: 'BL Lac object', BLA: 'Blazar',
    IR: 'Infrared source'
  });

  function idKey(value) {
    return value.toUpperCase().replace(/\s+/g, '');
  }

  function objectType(kind) {
    if (kind === 'DG') return 'Dark globule';
    if (kind === 'Cl+N') return 'Cluster with nebulosity';
    if (kind === 'HII') return 'H II emission region';
    if (kind.startsWith('ST:')) return stellariumTypes[kind.slice(3)] || 'Deep-sky object';
    return objectTypes[kind] || 'Deep-sky object';
  }

  function categoryFor(type) {
    if (/galaxy|galaxies|quasar|blazar|BL Lac/i.test(type)) return 'galaxies';
    if (/cluster|association|star cloud/i.test(type)) return 'clusters';
    if (/nebula|globule|emission region|cloud|supernova remnant|interstellar|star-forming/i.test(type)) return 'nebulae';
    if (/\bstar\b|stellar object|white dwarf/i.test(type)) return 'stars';
    return 'other';
  }

  function combineCatalogues(parts) {
    const index = new Map();
    const rows = [];
    for (const catalogue of parts) {
      for (const row of catalogue) {
        const [id, name, kind, , , mag, size, aliases = []] = row;
        const aliasRows = aliases.map(alias => index.get(idKey(alias))).filter(Boolean);
        // A cross-identification can denote a broader complex. Only use
        // an unambiguous IC/NGC/M or LBN match to merge a secondary row.
        const matchedAlias = kind.startsWith('ST:') && aliasRows.length === 1
          && aliases.some(alias => /^(IC|NGC|M|LBN)\s+\d/i.test(alias) && index.get(idKey(alias)) === aliasRows[0])
          ? aliasRows[0] : null;
        const match = index.get(idKey(id)) || matchedAlias;
        if (!match) {
          const copy = [...row];
          copy[7] = [...aliases];
          rows.push(copy);
          index.set(idKey(id), copy);
          continue;
        }

        if (!match[1]) match[1] = name;
        if (match[2] === 'Neb' && /^ST:(HII|EN|RN|DN|SNR|MOC|PN)$/.test(kind)) match[2] = kind;
        if (match[2] === '*Ass' && match[0] === 'M 24') match[2] = 'ST:SC';
        if (match[5] == null && Number.isFinite(mag)) match[5] = mag;
        if (match[6] == null && Number.isFinite(size)) match[6] = size;
        match[7] = Array.from(new Set([...match[7], id, ...aliases])).filter(alias => alias !== match[0]);
        if (!index.has(idKey(id))) index.set(idKey(id), match);
      }
    }
    return rows;
  }

  function annotate(wcs, catalog) {
    const { width, height, scale_arcsec: scale } = wcs;
    const objects = [];
    // Bounding the declination before the inverse WCS keeps dense catalogues
    // inexpensive, including when a FITS solution carries SIP polynomials.
    const corners = [
      wcs.pixelToWorld(-0.5,-0.5), wcs.pixelToWorld(width-0.5,-0.5),
      wcs.pixelToWorld(-0.5,height-0.5), wcs.pixelToWorld(width-0.5,height-0.5)
    ].filter(Boolean);
    const decBound = Math.max(wcs.fov.width_deg, wcs.fov.height_deg,
      ...corners.map(corner => separation(wcs.center, corner))) + 1;
    for (const [id, name, kind, ra, dec, mag, majorArcmin, aliases = [], priority = 0] of catalog) {
      if (Math.abs(dec - wcs.center.dec) > decBound) continue;
      const pixel = wcs.worldToPixel(ra, dec);
      if (!pixel) continue;
      const { x, y } = pixel;
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < -0.5 || x > width - 0.5
          || y < -0.5 || y > height - 0.5) continue;
      const type = objectType(kind);
      const radius_px = Number.isFinite(majorArcmin) && scale > 0 ? majorArcmin * 30 / scale : null;
      objects.push({ id, name, type, category: categoryFor(type), ra, dec, mag, x, y, radius_px, aliases, priority });
    }
    return { width, height, objects };
  }

  async function loadCatalog(urls, signal) {
    const files = Array.isArray(urls) ? urls : [urls];
    const parts = await Promise.all(files.map(async url => {
      const response = await fetch(url, {
        credentials: 'same-origin',
        referrerPolicy: 'no-referrer',
        mode: 'same-origin',
        signal
      });
      if (!response.ok) throw new Error('Could not load the local annotation catalogues.');
      const catalog = await response.json();
      if (![1, 2].includes(catalog.version) || !Array.isArray(catalog.objects)) {
        throw new Error('The local annotation catalogue is unreadable.');
      }
      return catalog.objects;
    }));
    return combineCatalogues(parts);
  }

  globalThis.PlateAnnotations = Object.freeze({ parseWcs, annotate, loadCatalog });
})();

/* On-device WCS row orientation from public reference stars and header metadata. */
(() => {
  'use strict';

  const radians = Math.PI / 180;

  function headerCards(input) {
    if (input instanceof ArrayBuffer) input = new Uint8Array(input);
    if (ArrayBuffer.isView(input)) {
      input = new TextDecoder().decode(
        new Uint8Array(input.buffer, input.byteOffset, Math.min(input.byteLength, 512 * 1024))
      );
    }
    if (typeof input !== 'string') return [];
    const text = input.trimStart();
    const lineEnd = text.search(/[\r\n]/);
    const cards = lineEnd >= 0 && lineEnd <= 80
      ? text.split(/\r\n|\r|\n/)
      : text.match(/[\s\S]{1,80}/g) || [];
    const end = cards.findIndex(card => card.trim() === 'END');
    return end < 0 ? cards : cards.slice(0, end);
  }

  function provenance(input) {
    const cards = headerCards(input);
    const rowOrder = cards.find(card => /^ROWORDER\s*=/i.test(card));
    if (rowOrder && /TOP[-_ ]?DOWN/i.test(rowOrder)) return 'top';
    if (rowOrder && /BOTTOM[-_ ]?UP/i.test(rowOrder)) return 'bottom';
    const notes = cards.filter(card => /^(COMMENT|HISTORY)\s/i.test(card)).join('\n');
    if (/astrometry\.net/i.test(notes)) {
      const sourceNotes = notes.split('\n').filter(line => /field name|source|input|original image|cmdline/i.test(line));
      const sourceText = sourceNotes.join('\n');
      if (/\.(jpe?g|png)(?![a-z0-9.])/i.test(sourceText)) return 'top';
      if (/\.(fits|fit|fts)(?![a-z0-9.])/i.test(sourceText) && !/\.(axy|xy\.fits|xyls)\b/i.test(sourceText)) {
        return 'bottom';
      }
    }
    const axes = cards.find(card => /^NAXIS\s*=\s*[2-9](?:\s|$)/.test(card));
    return axes ? 'bottom' : null;
  }

  function luminance(pixels) {
    const { width, height, rgba } = pixels;
    const result = new Float32Array(width * height);
    for (let i = 0; i < result.length; i++) {
      const r = i * 4;
      result[i] = (0.2126 * rgba[r] + 0.7152 * rgba[r+1] + 0.0722 * rgba[r+2]) * (rgba[r+3] / 255);
    }
    return result;
  }

  function blur(input, width, height, radius) {
    const scratch = new Float32Array(input.length);
    const result = new Float32Array(input.length);
    const denominator = 2 * radius + 1;
    for (let y = 0; y < height; y++) {
      const row = y * width;
      let sum = input[row] * radius;
      for (let x = 0; x <= radius; x++) sum += input[row + Math.min(x, width - 1)];
      for (let x = 0; x < width; x++) {
        scratch[row + x] = sum / denominator;
        sum += input[row + Math.min(x + radius + 1, width - 1)]
          - input[row + Math.max(x - radius, 0)];
      }
    }
    for (let x = 0; x < width; x++) {
      let sum = scratch[x] * radius;
      for (let y = 0; y <= radius; y++) sum += scratch[Math.min(y, height - 1) * width + x];
      for (let y = 0; y < height; y++) {
        result[y * width + x] = sum / denominator;
        sum += scratch[Math.min(y + radius + 1, height - 1) * width + x]
          - scratch[Math.max(y - radius, 0) * width + x];
      }
    }
    return result;
  }

  function peakPositions(gray, width, height, narrowRadius, broadRadius) {
    const narrow = blur(gray, width, height, narrowRadius);
    const broad = blur(gray, width, height, broadRadius);
    for (let i = 0; i < narrow.length; i++) narrow[i] -= broad[i];
    const peaks = [];
    for (let y = 4; y < height - 4; y++) {
      for (let x = 4; x < width - 4; x++) {
        const i = y * width + x;
        const strength = narrow[i];
        if (strength < 1 || narrow[i - 1] >= strength || narrow[i + 1] > strength
            || narrow[i - width] >= strength || narrow[i + width] > strength
            || narrow[i - width - 1] >= strength || narrow[i - width + 1] >= strength
            || narrow[i + width - 1] > strength || narrow[i + width + 1] > strength) continue;
        peaks.push({ x, y, strength });
      }
    }
    peaks.sort((a, b) => b.strength - a.strength);
    return peaks.slice(0, 220);
  }

  function angularDistance(first, second) {
    const deltaDec = (second.dec - first.dec) * radians;
    const deltaRa = (second.ra - first.ra) * radians;
    const chord = Math.sin(deltaDec / 2) ** 2
      + Math.cos(first.dec * radians) * Math.cos(second.dec * radians) * Math.sin(deltaRa / 2) ** 2;
    return 2 * Math.asin(Math.sqrt(Math.max(0, Math.min(1, chord)))) / radians;
  }

  function projectStars(wcs, reference, width, height, radius) {
    const corners = [
      wcs.pixelToWorld(0, 0), wcs.pixelToWorld(wcs.width - 1, 0),
      wcs.pixelToWorld(0, wcs.height - 1), wcs.pixelToWorld(wcs.width - 1, wcs.height - 1)
    ];
    const skyRadius = Math.max(...corners.map(point => angularDistance(wcs.center, point)));
    const decMargin = Math.min(180, skyRadius * 1.2 + 0.15);
    const stars = reference.filter(row => row[2] === '*' && Number.isFinite(row[3])
      && Number.isFinite(row[4]) && Math.abs(row[4] - wcs.center.dec) <= decMargin);
    stars.sort((first, second) => (first[5] ?? Infinity) - (second[5] ?? Infinity));
    const projected = [];
    for (const [, , , ra, dec] of stars) {
      if (projected.length >= 140) break;
      const p = wcs.worldToPixel(ra, dec);
      if (!p) continue;
      const x = (p.x + 0.5) * width / wcs.width - 0.5;
      const y = (p.y + 0.5) * height / wcs.height - 0.5;
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < radius || x >= width - radius
          || y < radius || y >= height - radius || Math.abs(height - 1 - 2*y) < 2 * radius) continue;
      projected.push({ x, y });
    }
    return projected;
  }

  function alignment(wcs, pixels, reference) {
    const { width, height } = pixels;
    if (width < 32 || height < 32 || !reference?.length) return null;
    const radius = Math.max(3, Math.min(11, Math.max(width, height) * 0.006));
    const expected = projectStars(wcs, reference, width, height, radius);
    if (expected.length < 5) return null;

    const gray = luminance(pixels);
    const fine = peakPositions(gray, width, height, 1, 4);
    const broad = peakPositions(gray, width, height, 3, 8);
    const peaks = fine.concat(broad);
    if (peaks.length < 5) return null;
    const usedTop = new Set();
    const usedBottom = new Set();
    const radiusSquared = radius ** 2;
    function closest(x, y) {
      let index = -1;
      let nearest = radiusSquared;
      for (let i = 0; i < peaks.length; i++) {
        const distance = (x - peaks[i].x) ** 2 + (y - peaks[i].y) ** 2;
        if (distance >= nearest) continue;
        nearest = distance;
        index = i;
      }
      return index;
    }
    for (const { x, y } of expected) {
      const bottom = closest(x, y);
      const top = closest(x, height - 1 - y);
      if (top >= 0 && bottom < 0) usedTop.add(top);
      if (bottom >= 0 && top < 0) usedBottom.add(bottom);
    }
    const top = usedTop.size;
    const bottom = usedBottom.size;
    const best = Math.max(top, bottom);
    const other = Math.min(top, bottom);
    const chance = Math.min(0.8, peaks.length * Math.PI * radiusSquared / (width * height));
    const margin = Math.max(4, Math.ceil(3 * Math.sqrt(2 * expected.length * chance)));
    const counts = { top, bottom, tested: expected.length };
    if (best < 5 || best < 2 * other + 1 || best - other < margin) return { rowOrigin: null, ...counts };
    return { rowOrigin: top > bottom ? 'top' : 'bottom', ...counts };
  }

  function resolve(header, bottomWcs, pixels, reference) {
    const evidence = pixels && reference ? alignment(bottomWcs, pixels, reference) : null;
    if (evidence?.rowOrigin) return { ...evidence, reason: 'alignment' };
    const declared = provenance(header);
    if (declared) return { rowOrigin: declared, reason: 'provenance', evidence };
    return { rowOrigin: 'bottom', reason: 'default', evidence };
  }

  globalThis.PlateWcsOrientation = Object.freeze({ resolve });
})();
