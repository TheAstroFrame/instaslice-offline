/* On-device solver. Requests use fixed, same-origin public asset URLs. */
'use strict';

async function readAsset(path) {
  const url = new URL(path, self.location.href);
  const response = await fetch(url, {
    mode: 'same-origin',
    credentials: 'same-origin',
    referrerPolicy: 'no-referrer',
    redirect: 'error'
  });
  if (!response.ok) throw new Error('The offline solver file could not be loaded.');
  return response.arrayBuffer();
}

async function solveWithIndex(compressed, rgba, width, height, narrow) {
  const decompressor = new DecompressionStream('gzip');
  const stream = new Blob([compressed]).stream().pipeThrough(decompressor);
  const index = await new Response(stream).arrayBuffer();
  const solver = new wasm_bindgen.PlateSolver(new Uint8Array(index));
  try {
    const result = narrow ? solver.solveNarrow(rgba, width, height) : solver.solve(rgba, width, height);
    return JSON.parse(result);
  } finally {
    solver.free();
  }
}

self.onmessage = async ({ data }) => {
  try {
    if (typeof WebAssembly !== 'object' || typeof DecompressionStream !== 'function') {
      throw new Error('This browser cannot run the offline solver. You can import a WCS from a local solver.');
    }
    self.postMessage({ type: 'status', message: 'Loading the offline solver and star indexes…' });
    importScripts('./tetra3.js');

    // Read the fixed public resources before examining the image. Catalogue
    // requests never reveal the selected search range or its result.
    const [wasm, wide, narrow] = await Promise.allSettled([
      readAsset('./tetra3_bg.wasm'),
      readAsset('../sky-index.bin.gz'),
      readAsset('./sky-index-narrow.bin.gz')
    ]);
    if (wasm.status !== 'fulfilled' || wide.status !== 'fulfilled' && narrow.status !== 'fulfilled') {
      throw new Error('The offline star indexes could not be loaded. Connect once to save the app for offline use, or import a WCS from a local solver.');
    }
    await wasm_bindgen({ module_or_path: wasm.value });

    const rgba = new Uint8Array(data.rgba.buffer, data.rgba.byteOffset, data.rgba.byteLength);
    let failure;
    for (const [pack, isNarrow] of [[wide, false], [narrow, true]]) {
      if (pack.status !== 'fulfilled') continue;
      self.postMessage({
        type: 'status',
        message: isNarrow ? 'Checking smaller telescope fields on this device…' : 'Detecting stars and solving on this device…'
      });
      try {
        const result = await solveWithIndex(pack.value, rgba, data.width, data.height, isNarrow);
        self.postMessage({ type: 'solution', ...result });
        return;
      } catch (error) {
        failure = error;
      } finally {
        pack.value = null;
      }
    }
    if (narrow.status !== 'fulfilled') {
      throw new Error('No match in the available star index. Connect once to save the narrow-field index, or import a WCS from a local solver.');
    }
    throw failure;
  } catch (error) {
    const message = typeof error === 'string' ? error : error && error.message;
    self.postMessage({ type: 'error', message: message || 'The offline solver could not complete the request.' });
  }
};
