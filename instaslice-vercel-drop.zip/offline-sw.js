// Cache only this app and its public astronomy assets. Image inputs and solve results stay in memory.
const CACHE_NAME = 'instaslice-offline-v1';
const appUrl = self.registration.scope;
const assetUrls = [
  'plate/worker.js',
  'plate/tetra3.js',
  'plate/tetra3_bg.wasm',
  'plate/sky-index.bin.gz',
  'plate/annotations.js',
  'plate/openngc.json',
  'plate/named-stars.json',
  'plate/DATA-CREDITS.txt',
  'plate/ANNOTATION-NOTICE.txt'
].map(path => new URL(path, self.registration.scope).href);
const offlineUrls = [appUrl, ...assetUrls];

self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

self.addEventListener('message', event => {
  const port = event.ports[0];
  if (!port || (event.data !== 'check' && event.data !== 'prepare')) return;

  event.waitUntil((async () => {
    try {
      const cache = await caches.open(CACHE_NAME);
      const cached = await Promise.all(offlineUrls.map(url => cache.match(url)));
      const missing = offlineUrls.filter((_, index) => !cached[index]);
      if (event.data === 'check' || !missing.length) {
        port.postMessage({ ready: !missing.length });
        return;
      }
      await cache.addAll(missing.map(url => new Request(url, {
        cache: 'reload', mode: 'same-origin', credentials: 'same-origin', redirect: 'error', referrerPolicy: 'no-referrer'
      })));
      port.postMessage({ ready: true });
    } catch (_) {
      port.postMessage({ ready: false });
    }
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  if (request.mode === 'navigate') {
    const url = new URL(request.url);
    const root = new URL(self.registration.scope);
    if (url.origin !== root.origin || (url.pathname !== root.pathname && url.pathname !== new URL('index.html', root).pathname)) return;
    event.respondWith(fetch(request).catch(async () => (await caches.match(appUrl, { cacheName: CACHE_NAME })) || Response.error()));
    return;
  }
  if (!assetUrls.includes(request.url)) return;
  event.respondWith((async () => {
    let cache;
    try {
      cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request.url);
      if (cached) return cached;
    } catch (_) { /* ordinary online loads can work without local storage */ }
    const response = await fetch(request);
    if (cache && response.ok) {
      try { await cache.put(request.url, response.clone()); }
      catch (_) { /* cache quota can be lower than the app's storage needs */ }
    }
    return response;
  })());
});
