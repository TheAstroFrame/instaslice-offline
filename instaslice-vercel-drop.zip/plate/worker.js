/* Offline browser solver. All URLs are fixed, same-origin public assets. */
'use strict';

let solverPromise;

async function readAsset(path, errorMessage) {
  let response;
  try {
    const url = new URL(path, self.location.href);
    response = await fetch(url, { mode: 'same-origin', credentials: 'same-origin', referrerPolicy: 'no-referrer', redirect: 'error' });
    if (response.ok) return response;
  } catch (_) {}
  throw new Error(errorMessage);
}

async function loadSolver() {
  if (typeof WebAssembly !== 'object' || typeof DecompressionStream !== 'function') {
    throw new Error('This browser cannot run the offline solver. You can import a local astrometry solution.');
  }
  try {
    importScripts('./tetra3.js');
  } catch (_) {
    throw new Error('The offline solver is unavailable. Connect once to download it, or import a local astrometry solution.');
  }
  const [wasmResponse, indexResponse] = await Promise.all([
    readAsset('./tetra3_bg.wasm', 'The offline solver is unavailable. Connect once to download it, or import a local astrometry solution.'),
    readAsset('./sky-index.bin.gz', 'The offline star index is unavailable. Connect once to download it, or import a local astrometry solution.')
  ]);
  const [wasm, index] = await Promise.all([
    wasmResponse.arrayBuffer(),
    new Response(indexResponse.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()
  ]);
  await wasm_bindgen({ module_or_path: wasm });
  return new wasm_bindgen.PlateSolver(new Uint8Array(index));
}

self.onmessage = async ({ data }) => {
  try {
    if (!solverPromise) {
      self.postMessage({ type: 'status', message: 'Loading the offline solver and star index…' });
      solverPromise = loadSolver().catch(error => {
        solverPromise = null;
        throw error;
      });
    }
    const solver = await solverPromise;
    self.postMessage({ type: 'status', message: 'Detecting stars and solving on this device…' });
    const rgba = new Uint8Array(data.rgba.buffer, data.rgba.byteOffset, data.rgba.byteLength);
    const result = JSON.parse(solver.solve(rgba, data.width, data.height));
    self.postMessage({ type: 'solution', ...result });
  } catch (error) {
    const message = typeof error === 'string' ? error : error && error.message;
    self.postMessage({ type: 'error', message: message || 'The offline solver could not complete the request.' });
  }
};
