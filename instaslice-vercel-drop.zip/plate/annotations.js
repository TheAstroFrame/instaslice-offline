/* Local celestial WCS projection and catalogue annotations. */
(() => {
  'use strict';

  const radians = Math.PI / 180;
  const wcsReadLimit = 1024 * 1024;
  const objectTypes = Object.freeze({
    '*': 'Star',
    '**': 'Double star',
    '*Ass': 'Stellar association',
    'Cl+N': 'Cluster with nebula',
    DrkN: 'Dark nebula',
    EmN: 'Emission nebula',
    G: 'Galaxy',
    GCl: 'Globular cluster',
    GGroup: 'Galaxy group',
    GPair: 'Galaxy pair',
    GTrpl: 'Galaxy triplet',
    HII: 'Emission nebula',
    Neb: 'Nebula',
    Nova: 'Nova',
    OCl: 'Open cluster',
    PN: 'Planetary nebula',
    RfN: 'Reflection nebula',
    SNR: 'Supernova remnant',
    Other: 'Other catalogue object'
  });

  function readHeader(input) {
    if (input instanceof ArrayBuffer) input = new Uint8Array(input);
    if (ArrayBuffer.isView(input)) {
      input = new TextDecoder().decode(
        new Uint8Array(input.buffer, input.byteOffset, Math.min(input.byteLength, wcsReadLimit))
      );
    }
    if (input && typeof input === 'object') {
      return Object.fromEntries(Object.entries(input).map(([key, value]) => [key.toUpperCase(), value]));
    }
    if (typeof input !== 'string') throw new Error('Choose a FITS WCS header for this image.');

    const header = Object.create(null);
    const text = input.replace(/^\uFEFF/, '').slice(0, wcsReadLimit).trimStart();
    const firstBreak = text.search(/[\r\n]/);
    const newlineSeparated = firstBreak >= 0 && firstBreak <= 80;
    const cards = newlineSeparated ? text.split(/\r?\n/) : text.match(/[\s\S]{1,80}/g) || [];
    for (const card of cards) {
      if (card.trim() === 'END') break;
      const match = card.match(/^\s*([A-Z0-9_-]{1,8})\s*=\s*(.*)/i);
      if (!match) continue;
      const [, key, rawValue] = match;
      const quoted = rawValue.match(/^'((?:[^']|'')*)'/);
      const value = quoted
        ? quoted[1].replace(/''/g, "'").trim()
        : rawValue.split('/')[0].trim();
      header[key.toUpperCase()] = value;
    }
    return header;
  }

  function number(header, key, fallback = NaN) {
    const value = header[key];
    if (typeof value === 'number') return value;
    if (typeof value !== 'string' || !value.trim()) return fallback;
    const parsed = Number(value.replace(/[dD]/, 'E'));
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function text(header, key) {
    const value = header[key];
    return typeof value === 'string' ? value.trim().toUpperCase() : '';
  }

  function dimension(header, imageKey, axisKey, fallback) {
    for (const value of [number(header, imageKey), number(header, axisKey), fallback]) {
      if (Number.isSafeInteger(value) && value > 0) return value;
    }
    throw new Error('The WCS does not specify image dimensions. Load the matching image first.');
  }

  function unitDegrees(header, key) {
    const unit = text(header, key);
    if (!unit || unit === 'DEG') return 1;
    if (unit === 'RAD') return 1 / radians;
    if (unit === 'ARCSEC') return 1 / 3600;
    if (unit === 'ARCMIN') return 1 / 60;
    throw new Error('The WCS uses unsupported sky-coordinate units.');
  }

  function readMatrix(header) {
    let values;
    const cdKeys = ['CD1_1', 'CD1_2', 'CD2_1', 'CD2_2'];
    const pcKeys = ['PC1_1', 'PC1_2', 'PC2_1', 'PC2_2'];
    if (cdKeys.some(key => key in header)) {
      values = cdKeys.map(key => number(header, key, 0));
    } else {
      const axis1 = number(header, 'CDELT1', 1);
      const axis2 = number(header, 'CDELT2', 1);
      if (pcKeys.some(key => key in header)) {
        values = [
          axis1 * number(header, 'PC1_1', 1),
          axis1 * number(header, 'PC1_2', 0),
          axis2 * number(header, 'PC2_1', 0),
          axis2 * number(header, 'PC2_2', 1)
        ];
      } else {
        const angle = number(header, 'CROTA2', number(header, 'CROTA1', 0)) * radians;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        values = [axis1 * cos, -axis2 * sin, axis1 * sin, axis2 * cos];
      }
    }
    const factor1 = unitDegrees(header, 'CUNIT1');
    const factor2 = unitDegrees(header, 'CUNIT2');
    return [values[0] * factor1, values[1] * factor1, values[2] * factor2, values[3] * factor2];
  }

  function readSip(header, prefix) {
    const order = number(header, prefix + '_ORDER', 0);
    if (!Number.isInteger(order) || order < 0 || order > 9) {
      throw new Error('The WCS uses an unsupported SIP polynomial order.');
    }
    const terms = [];
    for (let i = 0; i <= order; i++) {
      for (let j = 0; i + j <= order; j++) {
        const coefficient = number(header, prefix + '_' + i + '_' + j, 0);
        if (coefficient) terms.push({ i, j, coefficient });
      }
    }
    return terms;
  }

  function polynomial(terms, u, v) {
    let value = 0;
    for (const { i, j, coefficient } of terms) value += coefficient * u ** i * v ** j;
    return value;
  }

  function sipDerivatives(terms, u, v) {
    let du = 0;
    let dv = 0;
    for (const { i, j, coefficient } of terms) {
      if (i) du += coefficient * i * u ** (i - 1) * v ** j;
      if (j) dv += coefficient * j * u ** i * v ** (j - 1);
    }
    return [du, dv];
  }

  function inverseSip(targetU, targetV, a, b) {
    // Solve the forward SIP equations directly. The optional inverse SIP
    // polynomials are approximations and may be absent from a valid header.
    let u = targetU;
    let v = targetV;
    for (let attempt = 0; attempt < 15; attempt++) {
      const errorU = u + polynomial(a, u, v) - targetU;
      const errorV = v + polynomial(b, u, v) - targetV;
      if (Math.max(Math.abs(errorU), Math.abs(errorV)) < 1e-5) return [u, v];
      const [aU, aV] = sipDerivatives(a, u, v);
      const [bU, bV] = sipDerivatives(b, u, v);
      const determinant = (1 + aU) * (1 + bV) - aV * bU;
      if (!Number.isFinite(determinant) || Math.abs(determinant) < 1e-12) return null;
      u -= ((1 + bV) * errorU - aV * errorV) / determinant;
      v -= ((1 + aU) * errorV - bU * errorU) / determinant;
    }
    return null;
  }

  function separation(first, second) {
    const declination1 = first.dec * radians;
    const declination2 = second.dec * radians;
    const sinDec = Math.sin((declination2 - declination1) / 2);
    const sinRa = Math.sin((second.ra - first.ra) * radians / 2);
    const halfChord = sinDec ** 2 + Math.cos(declination1) * Math.cos(declination2) * sinRa ** 2;
    return 2 * Math.asin(Math.sqrt(Math.max(0, Math.min(1, halfChord)))) / radians;
  }

  function parseWcs(input, options = {}) {
    const header = readHeader(input);
    const axisOne = text(header, 'CTYPE1');
    const axisTwo = text(header, 'CTYPE2');
    const raFirst = /^RA---TAN(?:-SIP)?$/.test(axisOne) && /^DEC--TAN(?:-SIP)?$/.test(axisTwo);
    const decFirst = /^DEC--TAN(?:-SIP)?$/.test(axisOne) && /^RA---TAN(?:-SIP)?$/.test(axisTwo);
    if (!raFirst && !decFirst) throw new Error('This WCS is not an equatorial TAN or TAN-SIP solution.');

    const equinox = number(header, 'EQUINOX', number(header, 'EPOCH', 2000));
    const frame = text(header, 'RADESYS') || text(header, 'RADECSYS');
    if ((frame && frame !== 'ICRS' && frame !== 'FK5') || (frame !== 'ICRS' && equinox !== 2000)) {
      throw new Error('This WCS must use ICRS or J2000 equatorial coordinates.');
    }
    if (Object.keys(header).some(key => /^PV[12]_\d+$/.test(key))) {
      throw new Error('This WCS includes unsupported PV projection parameters.');
    }

    const width = dimension(header, 'IMAGEW', 'NAXIS1', options.width);
    const height = dimension(header, 'IMAGEH', 'NAXIS2', options.height);
    const rowOrigin = options.rowOrigin || 'bottom';
    if (rowOrigin !== 'top' && rowOrigin !== 'bottom') throw new Error('Invalid WCS row orientation.');

    const crpixX = number(header, 'CRPIX1');
    const crpixY = number(header, 'CRPIX2');
    const crval1 = number(header, 'CRVAL1') * unitDegrees(header, 'CUNIT1');
    const crval2 = number(header, 'CRVAL2') * unitDegrees(header, 'CUNIT2');
    const refRa = (raFirst ? crval1 : crval2) * radians;
    const refDec = (raFirst ? crval2 : crval1) * radians;
    const [m11, m12, m21, m22] = readMatrix(header);
    const [cd11, cd12, cd21, cd22] = raFirst ? [m11, m12, m21, m22] : [m21, m22, m11, m12];
    const determinant = cd11 * cd22 - cd12 * cd21;
    if (![crpixX, crpixY, refRa, refDec, determinant].every(Number.isFinite)
        || Math.abs(refDec) > Math.PI / 2 || determinant === 0) {
      throw new Error('The WCS does not contain a valid reference point and pixel transformation.');
    }
    const sinDec = Math.sin(refDec);
    const cosDec = Math.cos(refDec);
    const defaultPole = refDec === Math.PI / 2 ? 0 : 180;
    const poleAngle = (number(header, 'LONPOLE', defaultPole) - 180) * radians;
    const sinPole = Math.sin(poleAngle);
    const cosPole = Math.cos(poleAngle);
    const a = readSip(header, 'A');
    const b = readSip(header, 'B');

    // WCS pixels are 1-based. The raster row order is chosen separately from
    // the CD parity: Astrometry.net preserves JPEG/PNG row order in .wcs.
    function pixelToWorld(x, y) {
      if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
      const u = x + 1 - crpixX;
      const v = (rowOrigin === 'top' ? y + 1 : height - y) - crpixY;
      const correctedU = u + polynomial(a, u, v);
      const correctedV = v + polynomial(b, u, v);
      const plateX = (cd11 * correctedU + cd12 * correctedV) * radians;
      const plateY = (cd21 * correctedU + cd22 * correctedV) * radians;
      const east = cosPole * plateX + sinPole * plateY;
      const north = -sinPole * plateX + cosPole * plateY;
      const meridian = cosDec - north * sinDec;
      const ra = (refRa + Math.atan2(east, meridian)) / radians;
      const dec = Math.atan2(sinDec + north * cosDec, Math.hypot(east, meridian)) / radians;
      return { ra: ((ra % 360) + 360) % 360, dec };
    }

    function worldToPixel(ra, dec) {
      if (!Number.isFinite(ra) || !Number.isFinite(dec) || Math.abs(dec) > 90) return null;
      const deltaRa = ra * radians - refRa;
      const skyDec = dec * radians;
      const skySin = Math.sin(skyDec);
      const skyCos = Math.cos(skyDec);
      const cosDelta = Math.cos(deltaRa);
      const denominator = sinDec * skySin + cosDec * skyCos * cosDelta;
      if (denominator <= 1e-12) return null;
      const east = skyCos * Math.sin(deltaRa) / denominator / radians;
      const north = (cosDec * skySin - sinDec * skyCos * cosDelta) / denominator / radians;
      const plateX = cosPole * east - sinPole * north;
      const plateY = sinPole * east + cosPole * north;
      const targetU = (cd22 * plateX - cd12 * plateY) / determinant;
      const targetV = (cd11 * plateY - cd21 * plateX) / determinant;
      const uv = a.length || b.length ? inverseSip(targetU, targetV, a, b) : [targetU, targetV];
      if (!uv) return null;
      const x = uv[0] + crpixX - 1;
      const y = rowOrigin === 'top' ? uv[1] + crpixY - 1 : height - uv[1] - crpixY;
      return { x, y };
    }

    const cx = (width - 1) / 2;
    const cy = (height - 1) / 2;
    const center = pixelToWorld(cx, cy);
    const fov = {
      width_deg: separation(pixelToWorld(-0.5, cy), pixelToWorld(width - 0.5, cy)),
      height_deg: separation(pixelToWorld(cx, -0.5), pixelToWorld(cx, height - 0.5))
    };
    const scale_arcsec = Math.sqrt(Math.abs(determinant)) * 3600;
    return { solved: true, width, height, center, fov, scale_arcsec, worldToPixel, pixelToWorld };
  }

  function catalogueRank(object) {
    const mag = Number.isFinite(object.mag) ? object.mag : 15;
    const size = Number.isFinite(object.radius_px) ? object.radius_px : 0;
    return (object.id.startsWith('M ') ? 25 : 0) + (object.name ? 12 : 0)
      + Math.max(0, 16 - mag) + Math.min(10, Math.log2(1 + size));
  }

  function annotate(wcs, catalog) {
    const { width, height, scale_arcsec: scale } = wcs;
    const objects = [];
    for (const [id, name, kind, ra, dec, mag, majorArcmin] of catalog) {
      const pixel = wcs.worldToPixel(ra, dec);
      if (!pixel) continue;
      const { x, y } = pixel;
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < -0.5 || x > width - 0.5
          || y < -0.5 || y > height - 0.5) continue;
      const type = objectTypes[kind] || 'Deep-sky object';
      const radius_px = Number.isFinite(majorArcmin) && scale > 0 ? majorArcmin * 30 / scale : null;
      objects.push({ id, name, type, ra, dec, mag, x, y, radius_px });
    }
    objects.sort((first, second) => catalogueRank(second) - catalogueRank(first));
    return { width, height, objects };
  }

  async function loadCatalog(urls, signal) {
    const files = Array.isArray(urls) ? urls : [urls];
    const parts = await Promise.all(files.map(async url => {
      const response = await fetch(url, {
        credentials: 'same-origin',
        referrerPolicy: 'no-referrer',
        mode: 'same-origin',
        signal
      });
      if (!response.ok) throw new Error('Could not load the local annotation catalogues.');
      const catalog = await response.json();
      if (catalog.version !== 1 || !Array.isArray(catalog.objects)) {
        throw new Error('The local annotation catalogue is unreadable.');
      }
      return catalog.objects;
    }));
    return parts.flat();
  }

  globalThis.PlateAnnotations = Object.freeze({ parseWcs, annotate, loadCatalog });
})();
