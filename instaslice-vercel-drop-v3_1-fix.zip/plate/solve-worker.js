/* On-device solver. Requests use fixed, same-origin public asset URLs. */
'use strict';

async function readAsset(path) {
  const url = new URL(path, self.location.href);
  const response = await fetch(url, {
    mode: 'same-origin',
    credentials: 'same-origin',
    referrerPolicy: 'no-referrer',
    redirect: 'error'
  });
  if (!response.ok) throw new Error('The offline solver file could not be loaded.');
  return response.arrayBuffer();
}

async function solveWithIndex(compressed, rgba, width, height, method) {
  const decompressor = new DecompressionStream('gzip');
  const stream = new Blob([compressed]).stream().pipeThrough(decompressor);
  const index = await new Response(stream).arrayBuffer();
  const solver = new wasm_bindgen.PlateSolver(new Uint8Array(index));
  try {
    const result = solver[method](rgba, width, height);
    return JSON.parse(result);
  } finally {
    solver.free();
  }
}

self.onmessage = async ({ data }) => {
  try {
    if (typeof WebAssembly !== 'object' || typeof DecompressionStream !== 'function') {
      throw new Error('This browser cannot run the offline solver. You can import a WCS from a local solver.');
    }
    self.postMessage({ type: 'status', message: 'Loading the offline solver and star indexes…' });
    importScripts('./tetra3-runtime.js');

    // Read the fixed public resources before examining the image. Catalogue
    // requests never reveal the selected search range or its result.
    const [wasm, wide, narrow, andromeda] = await Promise.allSettled([
      readAsset('./tetra3-runtime.wasm'),
      readAsset('./sky-index.bin.gz'),
      readAsset('./sky-index-narrow.bin.gz'),
      readAsset('./sky-index-andromeda.bin.gz')
    ]);
    const indexes = [wide, narrow, andromeda];
    if (wasm.status !== 'fulfilled' || indexes.every(index => index.status !== 'fulfilled')) {
      throw new Error('The offline star indexes could not be loaded. Connect once to save the app for offline use, or import a WCS from a local solver.');
    }
    await wasm_bindgen({ module_or_path: wasm.value });

    const rgba = new Uint8Array(data.rgba.buffer, data.rgba.byteOffset, data.rgba.byteLength);
    let failure;
    const searches = [
      [wide, 'solve', 'Detecting stars and solving on this device…'],
      [narrow, 'solveNarrow', 'Checking smaller telescope fields on this device…'],
      [andromeda, 'solveCloseUp', 'Checking close-up fields near Andromeda…']
    ];
    for (const [pack, method, status] of searches) {
      if (pack.status !== 'fulfilled') continue;
      self.postMessage({
        type: 'status',
        message: status
      });
      try {
        const result = await solveWithIndex(pack.value, rgba, data.width, data.height, method);
        self.postMessage({ type: 'solution', ...result });
        return;
      } catch (error) {
        failure = error;
      } finally {
        pack.value = null;
      }
    }
    if (narrow.status !== 'fulfilled' || andromeda.status !== 'fulfilled') {
      throw new Error('No match in the available star indexes. Connect once to save the remaining star data, or import a WCS from a local solver.');
    }
    throw failure;
  } catch (error) {
    const message = typeof error === 'string' ? error : error && error.message;
    self.postMessage({ type: 'error', message: message || 'The offline solver could not complete the request.' });
  }
};
